define("epi-ecf-ui/widget/MarketingToolbar", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/topic",
    "dojo/when",
    "epi/shell/layout/ToolbarContainer",
    "epi/shell/widget/ToolbarLabel",
    "epi/shell/widget/ToolbarSet",
    "epi-cms/widget/NotificationStatusBar",
    "epi/i18n!epi/nls/commerce.widget.marketingtoolbar",
    "epi/i18n!epi/nls/episerver.shared"
], function (declare,
    lang,
    all,
    topic,
    when,
    ToolbarContainer,
    ToolbarLabel,
    ToolbarSet,
    NotificationStatusBar,
    resources,
    sharedResource
) {

    return declare([ToolbarSet], {
        // tags:
        //      public

        // currentContext: [public] Object
        //      An object with the current context information.
        currentContext: null,

        resources: resources,

        // _setupPromise: [private] String
        //      The setup children promise.
        _setupPromise: null,

        groupNames: {
            leading: "leading",
            center: "center",
            trailing: "trailing"
        },

        buttonNames: {
            saveButton: "saveButton",
            closeButton: "closeButton"
        },

        buildRendering: function() {
            // summary:
            //      Constructs the toolbar container and starts the children setup process.
            // tags:
            //      protected

            this.inherited(arguments);

            // Setup the children items in the toolbar.
            // Update the toolbar items with the current model.
            when(this._setupPromise = this.setupChildren(), this.updateChildren.bind(this));
        },

        isSetup: function () {
            // summary:
            //      Wait for setup to finish.
            // tags:
            //      protected

            return this._setupPromise;
        },

        setupChildren: function() {
            // summary:
            //      Setup the items in the toolbar. Inheriting classes should extend this to add more items to the toolbar.
            // tags:
            //      protected

            var toolbarGroups = [
            {
                name: this.groupNames.leading,
                type: "toolbargroup",
                settings: { region: "leading" }
            },
            {
                name: this.groupNames.center,
                type: "toolbargroup",
                settings: { region: "center" }
            },
            {
                name: this.groupNames.trailing,
                type: "toolbargroup",
                settings: { region: "trailing" }
            }];

            var toolbarItems = [{
                parent: this.groupNames.leading,
                name: "breadcrumbs",
                widgetType: "epi-cms/widget/Breadcrumb",
                settings: {
                    displayAsText: false,
                    showCurrentNode: false
                }
            },
            {
                parent: this.groupNames.leading,
                name: "currentcontent",
                widgetType: "epi-cms/widget/BreadcrumbCurrentItem"
            },
            {
                parent: this.groupNames.center,
                name: "notifications",
                widgetType: "epi-cms/widget/NotificationStatusBar"
            },
            {
                parent: this.groupNames.trailing,
                name: "viewselect",
                title: this.resources.discountpriorityview.title,
                widgetType: "dijit/form/Button",
                iconClass: "epi-iconForms",
                settings: {
                    showLabel: false,                    
                    "class": "epi-mediumButton epi-modeButton"
                },

                action: function () {
                    setTimeout(function () {
                        topic.publish("/epi/shell/action/changeview", "discountpriorityview", {}, { sender: this });
                    }.bind(this), 0);
                }
            }];

            return this.add(toolbarGroups).then(function () {
                this.add(toolbarItems);
                this.setItemVisibility("viewselect", false);
                return;
            }.bind(this));
        },

        updateChildren: function() {
            // summary:
            //      Update the toolbar items. This method is called on startup and whenever the current context is set.
            // tags:
            //      protected

            var context = this.currentContext,
                contentLink = context && context.id;

            this.setItemProperty("breadcrumbs", "contentLink", contentLink);
            this.setItemProperty("viewselect", "viewConfigurations", this.viewConfigurations);
            this.setItemProperty(
                "notifications",
                "notificationContext",
                { contextTypeName: "epi.cms.contentdata", contextId: contentLink });

            if (context) {
                this.setItemProperty("currentcontent", "currentItemInfo", {
                    name: context.name,
                    dataType: context.dataType
                });
            }
        },

        update: function(data) {
            // summary:
            //      Update the toolbar with new data.
            // data:
            //      Toolbar data model. Expected properties are: currentContext
            // tags:
            //      public

            if (!data) {
                return;
            }

            this.currentContext = data.currentContext;
            this.viewConfigurations = data.viewConfigurations;

            when(this.isSetup(), this.updateChildren.bind(this));
        },

        setViewSelectorVisible: function (visible) {
            this.setItemVisibility("viewselect", visible);
        },

        getActionButtons: function () {
            // summary:
            //      Gets the action buttons definition.
            // tags:
            //      public

            var buttonDefinition = {
                parent: this.groupNames.trailing,
                type: "button"
            };

            return {
                save: lang.mixin({
                    name: this.buttonNames.saveButton,
                    label: sharedResource.action.save,
                    settings: { disabled: true, "class": "epi-button--bold" }
                }, buttonDefinition),
                close: lang.mixin({
                    name: this.buttonNames.closeButton,
                    label: sharedResource.action.close,
                    settings: { "class": "epi-button--bold" }
                }, buttonDefinition)
            };
        },

        updateActionButtonStatus: function (buttonName, enabled) {
            // summary:
            //      Update state of action button
            // tags:
            //      Public
            this.setItemProperty(buttonName, "class", "epi-button--bold" + (enabled ? " epi-primary" : ""));
            this.setItemProperty(buttonName, "disabled", !enabled);
        }
    });
});