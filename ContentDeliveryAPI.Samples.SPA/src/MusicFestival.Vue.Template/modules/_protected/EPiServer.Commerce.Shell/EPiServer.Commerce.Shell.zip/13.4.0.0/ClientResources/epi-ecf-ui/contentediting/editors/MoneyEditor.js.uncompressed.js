require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/MoneyEditor.html':"﻿<div class=\"epi-moneyEditor dijitInline\">\r\n    <div data-dojo-type=\"dijit/form/NumberTextBox\" data-dojo-attach-point=\"amount\" data-dojo-props=\"placeHolder:'${resources.amount}', constraints: { min : 0}, rangeMessage : '${resources.invalidamount}'\"></div>\r\n    <div data-dojo-type=\"epi-ecf-ui/contentediting/editors/SelectionEditorWithEmptyOption\" data-dojo-attach-point=\"currency\" data-dojo-props=\"emptyOption:'${resources.emptyoption}'\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/MoneyEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/keys",
    "dojo/when",
    "dojo/on",
// dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/NumberTextBox",
    "dijit/focus",
// dojox
    "dojox/html/entities",
// epi
    "epi/epi",
    "epi/dependency",
    "epi/shell/widget/_ValueRequiredMixin",
// epi-ecf-ui
    "./SelectionEditorWithEmptyOption",
    "./_KeyboardBlurMixin",
// template
    "dojo/text!./templates/MoneyEditor.html",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.moneyeditor"
], function (
// dojo
    declare,
    lang,
    array,
    keys,
    when,
    on,
// dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    NumberTextBox,
    focusUtil,
// dojox
    htmlEntities,
// epi
    epi,
    dependency,
    _ValueRequiredMixin,
// epi-ecf-ui
    SelectionEditorWithEmptyOption,
    _KeyboardBlurMixin,
// template
    template,
// resources
    resources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _KeyboardBlurMixin, _ValueRequiredMixin], {
        // module:
        //  epi-ecf-ui/contentediting/editors/MoneyEditor
        // summary:
        //    Represents the widget to edit currency and amount.
        // tags:
        //    public

        templateString: template,

        resources: resources,

        value: null,

        allCurrencies: null,

        required: null,

        postCreate: function () {
            this.inherited(arguments);

            var updateValue = function(){
                var oldValue = this.value;
                var newValue = this.get("value");
                if (!epi.areEqual(newValue, oldValue)){
                    this._set("value", newValue);
                    this.onChange(newValue);
                }
            }.bind(this);
            this.own(
                this.currency.on("change", updateValue),
                this.amount.on("change", updateValue)
            );
            this.marketStore = this.marketStore || dependency.resolve("epi.storeregistry").get("epi.commerce.market");
        },

        onChange: function(newValue){
            if (!this.disabled){
                this.validate();
            }
        },

        _setRequiredAttr: function(value){
            this._set("required", value);
            this.amount.set("required", value);
        },

        _getValueAttr: function () {
            var oldValue = this.value;

            var newValue = {
                currency: this.currency.get("value"),
                amount: this.amount.get("value")
            };

            if (!newValue.currency || (!newValue.amount && newValue.amount !== 0)){
                return null;
            }
            if (epi.areEqual(newValue, oldValue)){
                return oldValue;
            } else {
                return newValue;
            }
        },

        _setValueAttr: function(value){
            this._set("value", value);
            this.currency.set("value", !!value ? value.currency : null);
            this.amount.set("value", !!value ? value.amount : null);
        },

        _setSelectionsAttr: function (selections) {
            this.currency.set("selections", selections);
            //we will only set this the first time where it will contain all currencies.
            if (!this.get("allCurrencies")){
                this.set("allCurrencies", selections);
            }
            this._set("selections", selections);
        },

        setCurrencySelections: function(marketId){
            //the curreny editor should only show currencies that match the current selected market.
            var currentValue = this.value;
            var currentCurrency = null;
            array.some(this.get("allCurrencies"), function(selection){
                if (selection.value === (currentValue ? currentValue.currency : null)){
                    currentCurrency = selection;
                    return true;
                }
            });

            when(this._getMarket(marketId), function(market){
                if (!market) {
                    return;
                }
                //create a copy of the array so that we can add values to if without affecting the market currencies
                var currenciesForSelectedMarket = market.currencies.slice(0);
                if(currentCurrency){
                    var marketHasCurrentCurrency = array.some(currenciesForSelectedMarket, function(currency){
                        return currency.value === currentCurrency.value;
                    });
                    //if the current currency does not exist in the selected market, we will add that currency as a selection.
                    if (!marketHasCurrentCurrency){
                        currenciesForSelectedMarket.push(currentCurrency);
                    }
                }
                this.set("selections", currenciesForSelectedMarket);
                //sometimes setting selections seems to clear the value of the selection editor
                this.set("value", currentValue);
            }.bind(this));
        },

        _getMarket : function(marketId){

            return when(this.marketStore.query(), function(marketList){
                var market = null;
                array.some(marketList, function (m) {
                    if (m.id === marketId) {
                        market = m;
                        return true;
                    }
                });
                return market;
            }.bind(this));
        },

        focus: function(){
            this.amount.focus();
        },

        isValid: function () {
            var isAmountValid = this.amount.isValid();
            if (!isAmountValid){
                this.amount.set("state", "Error");
                return false;
            }
            var isCurrencyValid = this.currency.isValid();
            var hasValidCurrencyValue = this.required ? this.currency.get("value") : true;
            if (!isCurrencyValid || !hasValidCurrencyValue){
                //I cant get client side validation on a select widget to work
                //thats why it's done this way
                this.currency.set("state", "Error");
                return false;
            }

            return true;
        },

        _onFocus: function(){
            //we override _ValueRequiredMixin _onFocus because we don't want to validate on focus. Only onBlur
            this.onFocus();
        }
    });
});
